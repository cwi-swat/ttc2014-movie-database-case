ttc2014-movie-database-case
===========================

Rascal submission to Transformation Tool Contest 2014 - The Movie Database Case

The benchmarks print a map from bechmark case to milliseconds (wall clock time).

To read usage information do:

	./run.sh
  
To benchmark generation of sinthesized data model(s) do:

	./run.sh generation 10 100

(In this case N=10, and N=100)
	
To benchmark grouping on synthesized model(s) do:

    ./run.sh cliques gen 2,3 10 100
    
The comma separated list indicates the group sizes to run benchmarks
on. NB: already with group size 3 it takes _very_ long. Do notice that for cliques of size 2 (i.e. couples), it is the specific algorithm for couples computation the one to be benchmarked. 
    
To benchmark grouping on .movies file(s) do:

    ./run.sh cliques 2,3 /home/user1/imdb1.movies /home/user1/imdb2.movies
    


