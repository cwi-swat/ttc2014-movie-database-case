#! /bin/sh
java -Xmx2G -Xss32m -jar rascal-shell.jar $@
